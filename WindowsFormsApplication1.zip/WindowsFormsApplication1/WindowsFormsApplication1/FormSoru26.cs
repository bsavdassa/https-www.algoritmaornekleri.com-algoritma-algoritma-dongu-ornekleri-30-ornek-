﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FormSoru26 : Form
    {
        public FormSoru26()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int toplam = 0, sayac = 0;
            for (int i = 1; i < int.Parse(this.textBox1.Text); i++)
            {
                if (i%2 != 0)
                {
                    toplam += i;
                    sayac++;
                }
            }
            this.label4.Text = toplam.ToString();
            this.label5.Text = (toplam / sayac).ToString();
        }
    }
}
