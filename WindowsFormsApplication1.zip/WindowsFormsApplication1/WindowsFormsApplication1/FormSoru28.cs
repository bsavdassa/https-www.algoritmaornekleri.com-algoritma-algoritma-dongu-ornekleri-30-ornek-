﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FormSoru28 : Form
    {
        public FormSoru28()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int randomSayi = 0;
            int toplamCift = 0, toplamTek = 0;
            for (int i = 0; i < 20; i++)
            {
                randomSayi = random.Next(0, 100);
                if (randomSayi%2 == 0 ||randomSayi == 0)
                {
                    toplamCift++;
                    continue;
                }
                toplamTek++;
                this.label4.Text = toplamTek.ToString();
                this.label5.Text = toplamCift.ToString();
            }
        }
    }
}
