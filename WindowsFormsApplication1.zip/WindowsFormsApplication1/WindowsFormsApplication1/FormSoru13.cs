﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FormSoru13 : Form
    {
        public FormSoru13()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int randomSayi = 0, sayac = 0;
            for (int i = 0; i < 10; i++)
            {
                randomSayi = random.Next(0, 99);
                if (randomSayi > 50)
                {
                    this.listBox1.Items.Add(randomSayi.ToString());
                    sayac++;
                }
            }
            this.label2.Text = sayac.ToString();
        }
    }
}
