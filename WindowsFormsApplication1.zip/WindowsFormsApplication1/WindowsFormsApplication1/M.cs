﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class M
    {
        public void ForLoop(ref System.Windows.Forms.ListBox listBox,int start, int end,int c = 1, string text = "")
        {
            listBox.Items.Clear();
            for (int i = start; i < end; i+= c)
			{
			    listBox.Items.Add(text.Replace("{\\}", i.ToString()+""));
			}
        }
    }
}
