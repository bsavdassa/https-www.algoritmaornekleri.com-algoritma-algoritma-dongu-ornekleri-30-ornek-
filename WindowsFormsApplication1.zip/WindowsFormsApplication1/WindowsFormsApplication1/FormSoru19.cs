﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FormSoru19 : Form
    {
        public FormSoru19()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int randomSayi = 0;
            Random random = new Random();
            for (int i = 0; i < 20; i++)
            {
                randomSayi = random.Next(1, 30);
                if (randomSayi>=18 && randomSayi <=25)
                {
                    this.listBox1.Items.Add(randomSayi.ToString());
                }
            }
        }
    }
}
