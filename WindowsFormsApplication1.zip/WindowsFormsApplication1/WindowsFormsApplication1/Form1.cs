﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private void OpenForm(Form form)
        {
            form.Location = this.Location;
            form.ShowDialog();
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            switch (this.comboBox1.Text)
            {
                case "1":
                    OpenForm(new FormSoru1());
                    break;
                case "2":
                    OpenForm(new FormSoru2());
                    break;
                case "3":
                    OpenForm(new FormSoru3());
                    break;
                case "4":
                    OpenForm(new FormSoru4());
                    break;
                case "5":
                    OpenForm(new FormSoru5());
                    break;
                case "6":
                    OpenForm(new FormSoru6());
                    break;
                case "7":
                    OpenForm(new FormSoru7());
                    break;
                case "8":
                    OpenForm(new FormSoru8());
                    break;
                case "9":
                    OpenForm(new FormSoru9());
                    break;
                case "10":
                    OpenForm(new FormSoru10());
                    break;
                case "11":
                    OpenForm(new FormSoru11());
                    break;
                case "12":
                    OpenForm(new FormSoru12());
                    break;
                case "13":
                    OpenForm(new FormSoru13());
                    break;
                case "14":
                    OpenForm(new FormSoru14());
                    break;
                case "15":
                    OpenForm(new FormSoru15());
                    break;
                case "16":
                    OpenForm(new FormSoru16());
                    break;
                case "17":
                    OpenForm(new FormSoru17());
                    break;
                case "18":
                    OpenForm(new FormSoru18());
                    break;
                case "19":
                    OpenForm(new FormSoru19());
                    break;
                case "20":
                    OpenForm(new FormSoru20());
                    break;
                case "21":
                    OpenForm(new FormSoru21());
                    break;
                case "22":
                    OpenForm(new FormSoru22());
                    break;
                case "23":
                    OpenForm(new FormSoru23());
                    break;
                case "24":
                    OpenForm(new FormSoru24());
                    break;
                case "25":
                    OpenForm(new FormSoru25());
                    break;
                case "26":
                    OpenForm(new FormSoru26());
                    break;
                case "27":
                    OpenForm(new FormSoru27());
                    break;
                case "28":
                    OpenForm(new FormSoru28());
                    break;
                case "29":
                    OpenForm(new FormSoru29());
                    break;
                case "30":
                    OpenForm(new FormSoru30());
                    break;
                default:
                    break;
            }
        }
    }
}
