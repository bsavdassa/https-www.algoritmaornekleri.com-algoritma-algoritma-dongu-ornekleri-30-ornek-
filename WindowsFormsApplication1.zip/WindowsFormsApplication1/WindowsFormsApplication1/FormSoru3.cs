﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FormSoru3 : Form
    {
        public FormSoru3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new M().ForLoop(ref this.listBox1, 0, 10, 1, " " + "{\\} "+this.textBox1.Text);
        }
    }
}
