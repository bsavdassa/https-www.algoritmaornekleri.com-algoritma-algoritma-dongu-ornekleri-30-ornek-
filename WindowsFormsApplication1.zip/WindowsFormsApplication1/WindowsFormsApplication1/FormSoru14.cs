﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FormSoru14 : Form
    {
        public FormSoru14()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sayi1 = int.Parse(this.textBox1.Text), sayi2 = int.Parse(this.textBox2.Text), sayi3 = int.Parse(this.textBox3.Text), sayi4 = int.Parse(this.textBox4.Text);
            if (sayi1 > 100 || sayi1 < 0 || sayi2 > 100 || sayi2 < 0 || sayi3 > 100 || sayi3 < 0 || sayi4 > 100 || sayi4 < 0)
            {
                MessageBox.Show("Girilen notlar 0-100 aralığında olmalıdır!");
                return;
            }
            this.label3.Text = "ortalama: " + ((sayi1 + sayi2 + sayi3 + sayi4) / 4).ToString();
            this.label2.Text = "toplam: " + (sayi1 + sayi2 + sayi3 + sayi4);
        }
    }
}
